
export const navigateToSuggestedSchedules = () => {
    const suggestedSchedulesContainer = document.querySelector("#suggestedSchedules")

    scrollViewNavigate(suggestedSchedulesContainer)
}

export const goBack = ({target}) => {

    handleGoBack(target.parentElement)
}

const handleGoBack = (container) => {
    document.body.style.backgroundColor = "#FFF"
    
    container.hidden = true
}
export const navigateToCreateSchedule = () => {
    const createScheduleContainer = document.querySelector("#createDate")

    scrollViewNavigate(createScheduleContainer)
}

const scrollViewNavigate = (container) => {
    container.hidden = false
    
    container.scrollIntoView({
        behavior: "smooth"
    })
    
    document.body.style.backgroundColor = "var(--ISlateCharcoal)"
    
}