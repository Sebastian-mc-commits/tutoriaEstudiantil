const views = {
  "create-class": "create-class",
  "suggest-date": "suggest-date",
  "user-detail": "user-detail"
}

export default views