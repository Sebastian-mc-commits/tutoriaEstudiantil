export const navigation = (view, ...params) => {
  location.href = './index'
}