export default {
    glob: {
        darkShade: "#042940",
        turquoise: "#005C53",
        yellowGreen: "#9FC131",
        brightYellow: "#DBF227",
        paleYellow: "#D6D58E"
    }
}