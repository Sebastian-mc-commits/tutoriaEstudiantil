
export const DOM_ENUM = {
  placeholder: 'placeholder',
  class: 'className',
  id: 'id',
  disabled: 'disabled',
  hidden: 'hidden',
  src: "src"
}

export const delimiter = "/**/"