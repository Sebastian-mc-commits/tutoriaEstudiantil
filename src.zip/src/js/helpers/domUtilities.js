
export const setRandomColorBetween = (colors = [], elementQueryId = '#randomColorElement') => {
    const elements = document.querySelectorAll(elementQueryId)
    const randomNumber = () => Math.floor(Math.random() * colors.length)
    const randomColor = () => colors[randomNumber()]

    Array.from(elements).forEach(child => {
        console.log(child)
        child.style.backgroundColor = randomColor()
    })
}

export const mutateDOM = (element, {
    errorCase,
    successCase = () => { },
    displayAlways = () => { }
}, timeOut = 200) => {

    if (!!element) {
        displayAlways()
    }
    else {
        errorCase()
        displayAlways()
    }


    setTimeout(successCase, timeOut)
}
