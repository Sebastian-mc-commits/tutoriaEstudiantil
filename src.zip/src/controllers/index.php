<?php

namespace Controller;

function getJson()
{
  $inputJSON = file_get_contents('php://input');

  return json_decode($inputJSON, true);
}
